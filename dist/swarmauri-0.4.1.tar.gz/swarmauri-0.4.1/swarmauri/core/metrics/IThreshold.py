from abc import ABC, abstractmethod

class IThreshold(ABC):
    pass
