from abc import ABC

class IAgentVectorStore(ABC):
    pass