from abc import ABC, abstractmethod

class IAgentSystemContext(ABC):
    pass