from abc import ABC

class IAgentRetrieve(ABC):
    pass