from abc import ABC, abstractmethod

class IMaxSize(ABC):
    pass