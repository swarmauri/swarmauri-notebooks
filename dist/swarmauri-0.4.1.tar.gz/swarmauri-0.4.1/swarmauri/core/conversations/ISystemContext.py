from abc import ABC, abstractmethod

class ISystemContext(ABC):
    pass
