from abc import ABC

class IDocument(ABC):
   pass