from swarmauri.standard.tools.base.ParameterBase import ParameterBase

class Parameter(ParameterBase):
    pass