from typing import Literal
from swarmauri.standard.vectors.base.VectorBase import VectorBase

class Vector(VectorBase):
    type: Literal['Vector'] = 'Vector'