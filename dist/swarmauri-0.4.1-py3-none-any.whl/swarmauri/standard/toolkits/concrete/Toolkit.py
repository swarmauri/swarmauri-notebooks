from typing import Literal
from swarmauri.standard.toolkits.base.ToolkitBase import ToolkitBase

class Toolkit(ToolkitBase):
    type: Literal['Toolkit'] = 'Toolkit'