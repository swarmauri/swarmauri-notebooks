from abc import ABC

class IAgentToolkit(ABC):
    pass